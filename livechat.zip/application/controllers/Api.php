<?php
defined('BASEPATH') OR exit('No direct script access allowed');

ini_set("memory_limit", "2048M");
ini_set('upload_max_filesize', '2048M');
ini_set('post_max_size', '1024M');
ini_set('max_execution_time', '1300');
ini_set('max_input_time', '1300');

class Api extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->database();
        header('Content-Type: application/json');
    }

    public function save() {
        $data = json_decode(file_get_contents("php://input"), true);

        $username = $data['username'] ?? 'Anonymous';
        $device_id = $data['device_id'] ?? '';
        $message = $data['message'] ?? '';
        $room_id = $data['room_id'] ?? '';

        if ($message !== '') {
            $this->db->insert('chat', [
                'username' => $username,
                'device_id' => $device_id,
                'message' => $message,
                'room_id' => $room_id
            ]);
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'empty']);
        }
    }

    public function device() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $client = $input['client_info'] ?? [];

            $user_agent = $client['userAgent'] ?? '';
            $platform = $client['platform'] ?? '';
            $language = $client['language'] ?? '';
            $resolution = $client['resolution'] ?? '';
            $device_memory = $client['deviceMemory'] ?? '';
            $gpu = $client['gpu'] ?? '';

            $get_device = $this->db->get_where('device', [
                                'user_agent' => $user_agent,
                                'platform' => $platform,
                                'resolution' => $resolution,
                                'gpu' => $gpu
                            ])->row();

            if(!$get_device){
                $this->db->insert('device', [
                    'user_agent' => $client['userAgent'] ?? '',
                    'platform' => $client['platform'] ?? '',
                    'language' => $client['language'] ?? '',
                    'resolution' => $client['resolution'] ?? '',
                    'device_memory' => $client['deviceMemory'] ?? '',
                    'gpu' => $client['gpu'] ?? '',
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                $device_id = $this->db->insert_id();
            }else{
                $device_id = $get_device->id;
            }

            echo json_encode(['device_id' => $device_id]);
        }
        return;
    }

    public function get_chat($room_id) {
        $query = $this->db->where('room_id', $room_id)->order_by('id', 'desc')->get('chat');
        echo json_encode(array_reverse($query->result()));
    }

    public function get_room($room_id)
    {
        // $params = $this->input->get(NULL,TRUE);

        if($room_id){
            $this->db->where('room_id',$room_id);
            $this->db->order_by('id', 'desc');
            $query = $this->db->get('room')->result_array();
        }

        $data['room_id'] = @$query ? $room_id : '';

        echo json_encode($data);
    }

    public function new_room()
    {
        $data['room_id'] = strtoupper(substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'), 0, 2)) . rand(100000, 999999);

        $this->db->insert('room', [
            'room_id' => $data['room_id']
        ]);

        echo json_encode($data);
    }

    public function connection()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['video'])) {
            $uploadDir = FCPATH . 'uploads\\'; // Windows pakai backslash
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

            $originalFilename = uniqid('video_') . '.webm';
            $originalPath = $uploadDir . $originalFilename;
            $ffmpegPath = "C:\\ffmpeg\\bin\\ffmpeg.exe"; 

            if (move_uploaded_file($_FILES['video']['tmp_name'], $originalPath)) {
                $compressedFilename = uniqid('compressed_') . '.mp4';
                $compressedPath = $uploadDir . $compressedFilename;

                $cmd = "\"$ffmpegPath\" -i \"$originalPath\" -vcodec libx264 -crf 28 -vf scale=640:-1 \"$compressedPath\"";
                exec($cmd . ' 2>&1', $output, $resultCode);

                if ($resultCode === 0) {
                    unlink($originalPath);
                    echo "Connection success, compress true";
                } else {
                    echo "Connection success, compress false";
                    echo "<pre>" . implode("\n", $output) . "</pre>";
                }
            } else {
                echo "Connection failed";
            }
        } else {
            echo "no connection";
        }
    }
}
