<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Live Chat</title>
    <script src="https://cdn.socket.io/4.7.2/socket.io.min.js"></script>
    <script type="text/javascript" src="<?= base_url('assets/js/app.js?') . date('Ymd-His') ?>"></script>
</head>
<body>
    <div>
        <!-- <button onclick="direct('chat')" id="btn-chat">Live Chat</button>
        <button onclick="direct('video')" id="btn-video">Video Call</button> -->
    </div>
    <h2>Live Chat <span id="room"></span></h2>
    <div>
        <input type="text" id="room_id" value="<?= $room_id?>" placeholder="ID Room">
        <button onclick="join_room()" id="join_room">Join</button>
        <span> or Create </span>
        <button onclick="new_room()" id="new_room">New Room</button>
        <div id="waiting"></div>
    </div>
    <div id="form-chat" style="margin-top: 10px;">
        <div id="chat-box" style="height:300px; overflow-y:scroll; border:1px solid #ccc; padding:10px;"></div>
        <form>
            <input type="hidden" id="room_id_hide" value="<?= $room_id?>">
            <input type="hidden" id="device_id_hide" value="<?= $device_id?>">
            <input type="text" id="username" placeholder="Nama" required><br>
            <div style="margin-top: 10px;">
                <textarea id="message" style="width: 500px; height:100px;" placeholder="Pesan" required></textarea>
            </div>
            <button onclick="sendMessage(event)" type="submit" style="font-size: 18px; padding: 10px 20px;">Kirim</button>

        </form>
    </div>
    <div style="margin-top: 20px;">
        <!-- <button onclick="direct('chat')" id="btn-chat2">Live Chat</button>
        <button onclick="direct('video')" id="btn-video2">Video Call</button> -->
    </div>
    <script type="text/javascript" src="<?= base_url('assets/js/chat.js?') . date('Ymd-His') ?>"></script>
    <!-- <?php if ($_SERVER['HTTP_HOST'] != 'localhost'): ?>
        <script type="text/javascript" src="<?= base_url('assets/js/inspect.js?') . date('Ymd-His') ?>"></script>
    <?php endif; ?> -->
    
</body>
</html>
