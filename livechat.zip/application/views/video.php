<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Video Call</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <?php if (@$_GET['cek_status'] == 'false'){ ?>
        <script type="text/javascript">const cek_status = 'false';</script>
    <?php }else{ ?>
        <script type="text/javascript">const cek_status = 'true';</script>
    <?php } ?>
    <!-- <style>
    #remoteVideos {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 10px;
        margin-top: 10px;
    }

    #remoteVideos video {
        width: 640px;
        height: 480px;
        object-fit: cover;
        border: 2px solid #ccc;
        border-radius: 8px;
        background-color: #000;
    }

    @media (max-width: 768px) {
        #remoteVideos video {
            width: 100%;
            height: auto;
            aspect-ratio: 4 / 3;
        }
    }
</style> -->

    <script src="https://cdn.socket.io/4.7.2/socket.io.min.js"></script>
    <script src="<?= base_url('assets/js/app.js?') . date('Ymd-His') ?>"></script>
</head>
    <div style="margin-top: 10px; margin: 1rem 0;">
        <button onclick="direct('chat')" id="btn-chat">Live Chat</button>
        <button onclick="direct('video')" id="btn-video">Video Call</button>
    </div>
    <div style="margin-top: 10px; margin: 1rem 0;">
        <!-- Tombol tambahan -->
        <button id="shareScreenBtn">Share Screen</button>
        <?php if (@$_GET['rekam'] == 'true'): ?>
            <button onclick="rekam()" id="recordBtn">Mulai Rekam</button>
        <?php endif; ?>
            <span id="recordStatus"></span>

        <!-- Status Koneksi -->
        <div id="connectionStatus"></div>
    </div>
    <h2>Video Call</h2>
    <div style="margin-top: 10px; margin: 1rem 0;">
        <button id="muteAudioBtn" style="font-size: 24px; padding: 10px 15px;"><i class="bi bi-mic-fill"></i></button>
        <button id="muteSoundBtn" style="font-size: 24px; padding: 10px 15px;"><i class="bi bi-volume-up-fill"></i></button>
    </div>
    <select id="cameraSelect">
        <option value="" disabled>Select Camera</option>
    </select>
    <p id="cameraStatus">Sedang memuat list kamera, silakan tunggu... <span id="detik"></span></p>

    <div class="row" id="remoteVideos">
        <video id="screenVideo" autoplay muted style="display: none;"></video>
        <video id="localVideo" autoplay muted></video>
    </div>

    <script src="<?= base_url('assets/js/video.js?') . date('Ymd-His') ?>"></script>
    <!-- <?php if ($_SERVER['HTTP_HOST'] != 'localhost'): ?>
        <script type="text/javascript" src="<?= base_url('assets/js/inspect.js?') . date('Ymd-His') ?>"></script>
    <?php endif; ?> -->
</body>
</html>
